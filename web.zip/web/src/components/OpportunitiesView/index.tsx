export { default } from './OpportunitiesView'
